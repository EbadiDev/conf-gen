"""Common output, file system, and formatting utilities."""

import json
import os
import socket
from pathlib import Path
from typing import Any, Dict, Optional, Union
from urllib.request import Request, urlopen


# ANSI Color Codes
RED = "\033[0;31m"
GREEN = "\033[0;32m"
YELLOW = "\033[1;33m"
BLUE = "\033[0;34m"
NC = "\033[0m"


def print_info(msg: str) -> None:
    print(f"{BLUE}[INFO]{NC} {msg}", flush=True)


def print_success(msg: str) -> None:
    print(f"{GREEN}[SUCCESS]{NC} {msg}", flush=True)


def print_warning(msg: str) -> None:
    print(f"{YELLOW}[WARNING]{NC} {msg}", flush=True)


def print_error(msg: str) -> None:
    print(f"{RED}[ERROR]{NC} {msg}", flush=True)


def get_public_ip(timeout: float = 2.0) -> Optional[str]:
    """Auto-detect public IPv4 address of this machine."""
    services = [
        "https://api.ipify.org",
        "https://ifconfig.me/ip",
        "https://icanhazip.com",
    ]
    for url in services:
        try:
            req = Request(url, headers={"User-Agent": "curl/7.68.0"})
            with urlopen(req, timeout=timeout) as resp:
                cand = resp.read().decode("utf-8").strip()
                if cand and cand.count(".") == 3 and not cand.startswith("127."):
                    return cand
        except Exception:
            continue
    # Fallback to local egress socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        cand = s.getsockname()[0]
        s.close()
        if cand and not cand.startswith("127."):
            return cand
    except Exception:
        pass
    return None


def resolve_variables(config: Dict[str, Any]) -> Dict[str, Any]:
    """Resolve $variable$ tokens within node settings using config['variables'].

    Preserves the top-level 'variables' dictionary for documentation, but
    ensures all node settings contain concrete data types (integers, strings, lists)
    as required by WaterWall's native C++ JSON schema parser.
    """
    vars_map = config.get("variables", {})
    if not vars_map or "nodes" not in config:
        return config

    def _resolve(val: Any) -> Any:
        if isinstance(val, dict):
            return {k: _resolve(v) for k, v in val.items()}
        elif isinstance(val, list):
            return [_resolve(v) for v in val]
        elif isinstance(val, str):
            if val.startswith("$") and val.endswith("$") and val.count("$") == 2:
                var_key = val[1:-1]
                if var_key in vars_map:
                    return vars_map[var_key]
            elif "$" in val:
                for k, v in vars_map.items():
                    token = f"${k}$"
                    if token in val:
                        val = val.replace(token, str(v))
                return val
            return val
        return val

    config["nodes"] = _resolve(config["nodes"])
    return config


def write_json(data: Dict[str, Any], filepath: str | Path, indent: int = 2) -> Path:
    """Safely write JSON configuration to a destination file."""
    if "variables" in data and "nodes" in data:
        data = resolve_variables(data)

    p = Path(filepath)
    if not p.suffix:
        p = p.with_suffix(".json")
    
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=indent, ensure_ascii=False)
        f.write("\n")
    
    print_success(f"Configuration written: {p.resolve()}")
    return p


def get_waterwall_dir() -> Path:
    """Locate active WaterWall directory (prefers cwd if core.json/Waterwall present, else /root/waterwall)."""
    cwd = Path.cwd()
    if (cwd / "core.json").exists() or (cwd / "Waterwall").exists():
        return cwd
    prod_dir = Path("/root/waterwall")
    try:
        if prod_dir.is_dir() and os.access(prod_dir, os.W_OK):
            return prod_dir
    except Exception:
        pass
    return cwd


def update_core_json(config_name: str | Path, core_path: Optional[str | Path] = None) -> None:
    """Add generated config to core.json (creating core.json if not present)."""
    cp = Path(core_path) if core_path else (get_waterwall_dir() / "core.json")
    cfg_filename = Path(config_name).name
    if not cfg_filename.endswith(".json"):
        cfg_filename = f"{cfg_filename}.json"
    
    if not cp.exists():
        initial_data = {
            "log": {
                "path": "log/",
                "internal": {"loglevel": "WARN", "console": False},
                "core": {"loglevel": "WARN", "console": False},
                "network": {"loglevel": "WARN", "console": False},
                "dns": {"loglevel": "WARN", "console": False},
            },
            "dns": {},
            "misc": {
                "workers": 0,
                "ram-profile": "server",
                "mtu": 1400,
                "libs-path": "libs/",
            },
            "configs": [cfg_filename],
        }
        cp.parent.mkdir(parents=True, exist_ok=True)
        with open(cp, "w", encoding="utf-8") as f:
            json.dump(initial_data, f, indent=4)
            f.write("\n")
        print_info(f"Created core.json at {cp} with {cfg_filename}")
        return

    try:
        with open(cp, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        configs = data.get("configs", [])
        if not isinstance(configs, list):
            configs = []
        if cfg_filename not in configs:
            configs.append(cfg_filename)
            data["configs"] = configs
            with open(cp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)
                f.write("\n")
            print_info(f"Added {cfg_filename} to {cp}")
        else:
            print_info(f"Configuration {cfg_filename} already exists in {cp}")
    except Exception as e:
        print_warning(f"Failed to update {cp}: {e}")


def save_waterwall_config(
    data: Dict[str, Any],
    filepath: Optional[Union[str, Path]] = None,
    name: Optional[str] = None,
    auto_core: bool = True,
    core_path: Optional[Union[str, Path]] = None,
) -> Path:
    """Write WaterWall config and automatically synchronize with core.json."""
    base_dir = get_waterwall_dir()
    if filepath:
        target = Path(filepath)
    elif name:
        target = base_dir / f"{name}.json"
    else:
        target = base_dir / "config.json"

    if not target.suffix:
        target = target.with_suffix(".json")

    written_path = write_json(data, target)

    if auto_core:
        c_path = Path(core_path) if core_path else (target.parent / "core.json")
        update_core_json(target.name, core_path=c_path)

    return written_path

